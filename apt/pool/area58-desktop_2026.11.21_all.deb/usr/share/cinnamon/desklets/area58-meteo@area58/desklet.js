// Area58 Neural AI — il tempo sopra lo sfondo: nuvoletta, temperatura, tempo e luogo.
// Come l'applet nella barra, non chiede niente a internet: legge ~/.cache/area58/meteo.json,
// scritto da area58-giorno-notte (le stesse previsioni che cambiano lo sfondo del castello).
// Un clic apre la scelta del luogo. Sta sempre agganciato in alto a destra, sotto la barra,
// a qualsiasi risoluzione: si rimette lì all'avvio e quando cambia lo schermo.
const Desklet = imports.ui.desklet;
const St = imports.gi.St;
const GLib = imports.gi.GLib;
const Mainloop = imports.mainloop;
const ByteArray = imports.byteArray;
const Util = imports.misc.util;
const Gio = imports.gi.Gio;
const Main = imports.ui.main;
const Pango = imports.gi.Pango;

const FILE = GLib.get_home_dir() + "/.cache/area58/meteo.json";
const OGNI_SECONDI = 60;
// Le icone disegnate per Area58 (genera-icone-meteo.py), al posto di quelle di sistema
const ICONE = {
    "weather-clear-symbolic": "sereno-giorno", "weather-clear-night-symbolic": "sereno-notte",
    "weather-few-clouds-symbolic": "poco-nuvoloso-giorno", "weather-few-clouds-night-symbolic": "poco-nuvoloso-notte",
    "weather-overcast-symbolic": "nuvoloso", "weather-showers-symbolic": "pioggia",
    "weather-showers-scattered-symbolic": "pioggia", "weather-snow-symbolic": "neve",
    "weather-storm-symbolic": "temporale", "weather-fog-symbolic": "nebbia",
};

class Area58MeteoDesklet extends Desklet.Desklet {
    constructor(metadata, desklet_id) {
        super(metadata, desklet_id);
        this._timer = 0;
        this._cartella = metadata.path;
        let riquadro = new St.BoxLayout({ vertical: false, style_class: "area58-meteo" });
        this._riquadro = riquadro;
        this._icona = new St.Icon({ icon_size: 67 });
        let testi = new St.BoxLayout({ vertical: true, style_class: "area58-meteo-testi" });
        this._temperatura = new St.Label({ text: "", style_class: "area58-meteo-temperatura" });
        this._descrizione = new St.Label({ text: "", style_class: "area58-meteo-descrizione" });
        this._luogo = new St.Label({ text: "", style_class: "area58-meteo-luogo" });
        // senza riquadro le scritte non vanno mai tagliate con "…": il desklet si allarga quanto serve
        for (let etichetta of [this._temperatura, this._descrizione, this._luogo])
            etichetta.clutter_text.set_ellipsize(Pango.EllipsizeMode.NONE);
        testi.add_actor(this._temperatura);
        testi.add_actor(this._descrizione);
        testi.add_actor(this._luogo);
        riquadro.add_actor(this._icona);
        riquadro.add_actor(testi);
        this.setContent(riquadro);
        // stesso colore del dock: segue il tema chiaro/scuro del desktop
        this._interfaccia = new Gio.Settings({ schema_id: "org.cinnamon.desktop.interface" });
        this._tema = this._interfaccia.connect("changed::gtk-theme", () => this._seguiTema());
        this._seguiTema();
        this._aggiorna();
        this._timer = Mainloop.timeout_add_seconds(OGNI_SECONDI, () => { this._aggiorna(); return true; });
        // Cinnamon mette il desklet nella posizione salvata dopo averlo creato: si aggancia un attimo dopo
        this._agganciato = false;
        this._aggancio = Mainloop.timeout_add(800, () => {
            this._agganciaADestra(); this._agganciato = true; this._aggancio = 0; return false;
        });
        this._schermi = Main.layoutManager.connect("monitors-changed", () => this._agganciaADestra());
    }

    _agganciaADestra() {
        try {
            let schermo = Main.layoutManager.primaryMonitor;
            let scala = global.ui_scale || 1;
            let margine = 24 * scala;
            let x = schermo.x + schermo.width - this.actor.get_width() - margine;
            let y = schermo.y + 44 * scala;                  // sotto la barra in alto
            this.actor.set_position(Math.max(schermo.x, Math.round(x)), Math.round(y));
        } catch (e) {
            global.logError("area58-meteo: " + e);
        }
    }

    _leggi() {
        try {
            let [ok, contenuto] = GLib.file_get_contents(FILE);
            return ok ? JSON.parse(ByteArray.toString(contenuto)) : null;
        } catch (e) {
            return null;
        }
    }

    _seguiTema() {
        let scuro = /dark/i.test(this._interfaccia.get_string("gtk-theme"));
        this._riquadro.remove_style_class_name(scuro ? "chiaro" : "scuro");
        this._riquadro.add_style_class_name(scuro ? "scuro" : "chiaro");
    }

    _mostraIcona(nome) {
        let file = ICONE[nome] ? this._cartella + "/icone/" + ICONE[nome] + ".png" : null;
        if (file && GLib.file_test(file, GLib.FileTest.EXISTS)) {
            this._icona.gicon = new Gio.FileIcon({ file: Gio.File.new_for_path(file) });
        } else {
            this._icona.gicon = null;
            this._icona.icon_name = nome;           // per esempio "senza rete": l'icona di sistema
        }
    }

    _aggiorna() {
        let d = this._leggi();
        if (!d || d.spento) {
            this._mostraIcona("weather-few-clouds-symbolic");
            this._temperatura.text = "—";
            this._descrizione.text = d && d.spento ? "Meteo spento" : "In attesa delle previsioni…";
            this._luogo.text = "Clicca per scegliere il luogo";
            return;
        }
        if (d.errore) {
            this._mostraIcona("network-offline-symbolic");
            this._temperatura.text = "—";
            this._descrizione.text = "Previsioni non raggiungibili";
            this._luogo.text = (d.luogo || "").toUpperCase();
            return;
        }
        this._mostraIcona(d.icona || "weather-few-clouds-symbolic");
        this._temperatura.text = typeof d.temperatura === "number" ? Math.round(d.temperatura) + "°" : "—";
        this._descrizione.text = d.descrizione || "";
        this._luogo.text = (d.luogo ? d.luogo.toUpperCase() + "  ·  " : "") + d.aggiornato;
        // il testo cambia lunghezza (paese, ora, tempo): si riaggancia all'angolo destro
        if (this._agganciato) Mainloop.idle_add(() => { this._agganciaADestra(); return false; });
    }

    on_desklet_clicked(event) {
        Util.spawnCommandLine("/usr/local/bin/area58-giorno-notte --luogo");
    }

    on_desklet_removed() {
        if (this._timer) Mainloop.source_remove(this._timer);
        if (this._aggancio) Mainloop.source_remove(this._aggancio);
        if (this._schermi) Main.layoutManager.disconnect(this._schermi);
        if (this._tema) this._interfaccia.disconnect(this._tema);
        this._timer = 0;
    }
}

function main(metadata, desklet_id) {
    return new Area58MeteoDesklet(metadata, desklet_id);
}
