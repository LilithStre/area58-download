// Area58 Neural AI — lo stemma del menu, nella barra in alto, pulsa lentamente.
// Cambia solo la trasparenza dell'icona, pochi passi al secondo: nessun ridisegno,
// consumo trascurabile. Per spegnerlo: Impostazioni di sistema > Estensioni.
const GLib = imports.gi.GLib;
const AppletManager = imports.ui.appletManager;

const MENU = "menu@cinnamon.org";
const PERIODO_MS = 4200;     // un respiro completo
const PASSO_MS = 70;         // circa 14 passi al secondo
const MINIMO = 105;          // trasparenza nel punto più spento (255 = pieno)

let timer = 0;
let inizio = 0;
let icona = null;

// L'icona del menu: l'applet può non esistere ancora all'avvio, o rinascere se il pannello viene ricaricato.
function trovaIcona() {
    let applet = null;
    try {
        let attivi = AppletManager.getRunningInstancesForUuid(MENU);
        if (attivi && attivi.length > 0) applet = attivi[0];
    } catch (e) { /* versione senza questa funzione: si prova nell'altro modo */ }
    if (!applet) {
        try {
            for (let id in AppletManager.appletObj) {
                let a = AppletManager.appletObj[id];
                if (a && a._uuid === MENU) { applet = a; break; }
            }
        } catch (e) { /* niente applet per ora */ }
    }
    if (!applet) return null;
    return applet._applet_icon_box || applet.actor || null;
}

function passo() {
    try {
        if (!icona) icona = trovaIcona();
        if (icona) {
            let t = ((GLib.get_monotonic_time() / 1000 - inizio) % PERIODO_MS) / PERIODO_MS;
            let onda = 0.5 + 0.5 * Math.cos(2 * Math.PI * t);          // da 1 a 0 e ritorno
            icona.opacity = Math.round(MINIMO + (255 - MINIMO) * onda);
        }
    } catch (e) {
        icona = null;        // l'icona non c'è più (pannello ricaricato): si ricerca al prossimo passo
    }
    return true;             // continua
}

function init(metadata) {
}

function enable() {
    inizio = GLib.get_monotonic_time() / 1000;
    if (!timer) timer = GLib.timeout_add(GLib.PRIORITY_LOW, PASSO_MS, passo);
}

function disable() {
    if (timer) { GLib.source_remove(timer); timer = 0; }
    try { if (icona) icona.opacity = 255; } catch (e) { /* già distrutta */ }
    icona = null;
}
