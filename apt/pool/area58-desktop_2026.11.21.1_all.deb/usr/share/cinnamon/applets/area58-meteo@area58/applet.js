// Area58 Neural AI — il tempo nella barra in alto: "Prata d'Ansidonia · 12° · Nebbia".
// Non chiede niente a internet: legge ~/.cache/area58/meteo.json, che scrive area58-giorno-notte
// (le stesse previsioni che cambiano lo sfondo del castello). Il luogo e il nome si impostano in
// ~/.config/area58/giorno-notte con le righe luogo=lat,lon e nome=...
const Applet = imports.ui.applet;
const GLib = imports.gi.GLib;
const Mainloop = imports.mainloop;
const ByteArray = imports.byteArray;
const Util = imports.misc.util;

const FILE = GLib.get_home_dir() + "/.cache/area58/meteo.json";
const OGNI_SECONDI = 60;

class Area58Meteo extends Applet.TextIconApplet {
    constructor(metadata, orientation, panel_height, instance_id) {
        super(orientation, panel_height, instance_id);
        this._timer = 0;
        this.set_applet_icon_symbolic_name("weather-few-clouds-symbolic");
        this.set_applet_label("");
        this.set_applet_tooltip("Meteo: in attesa delle previsioni…");
        this._aggiorna();
        this._timer = Mainloop.timeout_add_seconds(OGNI_SECONDI, () => { this._aggiorna(); return true; });
    }

    _leggi() {
        try {
            let [ok, contenuto] = GLib.file_get_contents(FILE);
            if (!ok) return null;
            return JSON.parse(ByteArray.toString(contenuto));
        } catch (e) {
            return null;                               // il file non c'è ancora
        }
    }

    _aggiorna() {
        let d = this._leggi();
        if (!d || d.spento) {                          // meteo spento (meteo=no) o mai scaricato
            this.set_applet_label("");
            this.set_applet_icon_symbolic_name("weather-few-clouds-symbolic");
            this.set_applet_tooltip(d && d.spento
                ? "Meteo spento: togli la riga meteo=no da ~/.config/area58/giorno-notte"
                : "Meteo: in attesa delle previsioni…\nClicca per scegliere il luogo");
            return;
        }
        if (d.errore) {
            this.set_applet_label(d.luogo ? d.luogo + " · —" : "—");
            this.set_applet_icon_symbolic_name("network-offline-symbolic");
            this.set_applet_tooltip("Previsioni non raggiungibili (ultimo tentativo alle " + d.aggiornato
                + "): senza internet lo sfondo resta sereno.");
            return;
        }
        let parti = [];
        if (d.luogo) parti.push(d.luogo);
        if (typeof d.temperatura === "number") parti.push(Math.round(d.temperatura) + "°");
        if (d.descrizione) parti.push(d.descrizione);
        this.set_applet_label(parti.join(" · "));
        this.set_applet_icon_symbolic_name(d.icona || "weather-few-clouds-symbolic");
        this.set_applet_tooltip((d.descrizione || "Meteo") + (d.luogo ? " a " + d.luogo : "")
            + "\nAggiornato alle " + d.aggiornato + " · Dati: MET Norway (CC BY 4.0)"
            + "\nClicca per cambiare il luogo");
    }

    // un clic: si sceglie il luogo scrivendo il nome del paese
    on_applet_clicked(event) {
        Util.spawnCommandLine("/usr/local/bin/area58-giorno-notte --luogo");
    }

    on_applet_removed_from_panel() {
        if (this._timer) Mainloop.source_remove(this._timer);
        this._timer = 0;
    }
}

function main(metadata, orientation, panel_height, instance_id) {
    return new Area58Meteo(metadata, orientation, panel_height, instance_id);
}
